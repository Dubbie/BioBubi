<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-start mb-4">
            <h1 class="font-weight-bold">Termékek</h1>
            <div class="btn-toolbar">
                <button type="button" class="btn btn-sm btn-outline-dark" data-toggle="modal"
                        data-target="#newItemModal">
                    Új termék
                </button>
            </div>
        </div>

        
        <?php if(count($items) > 0): ?>
            <div class="row">
                <div class="col-md-8">
                    <table class="table table-borderless">
                        <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Név</th>
                            <th scope="col" class="text-right">Ár</th>
                            <th scope="col" class="text-right">Rögzítve</th>
                            <th scope="col"></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="action-hover-only"
                                data-redirect-to="<?php echo e(action('ItemsController@show', $item)); ?>">
                                <td class="text-muted"><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td class="text-right"><?php echo e($item->getFormattedPrice(true)); ?></td>
                                <td class="text-right">
                                    <?php
                                        $count = 0;

                                        foreach($item->purchases as $purchase) {
                                            $count += $purchase->quantity;
                                        }
                                    ?>

                                    <?php echo e($count . 'db'); ?>

                                </td>
                                <td class="td-action text-right">
                                    <button class="btn btn-edit-item btn-sm btn-muted px-1 py-0" data-toggle="modal"
                                            data-target="#editItemModal"
                                            data-item-id="<?php echo e($item->id); ?>"
                                            data-item-name="<?php echo e($item->name); ?>"
                                            data-item-price="<?php echo e($item->price); ?>">
                                        <span class="icon">
                                            <i class="fas fa-pen"></i>
                                        </span>
                                    </button>
                                    <form action="<?php echo e(action('ItemsController@delete', $item)); ?>" class="d-inline-block"
                                          method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-del-item btn-sm btn-muted px-1 py-0">
                                            <span class="icon">
                                                <i class="far fa-times-circle"></i>
                                            </span>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="col-md-4">
                    <div class="alert alert-info">
                        <p class="lead mb-0">Az itt szereplő termékek azok, amiket akkor látsz, ha új vásárlást
                            rögzítesz egy felhasználóhoz.</p>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <p class="lead mb-2">Nincsen még termék az adatbázisban.</p>
            <p>
                <button type="button" class="btn btn-sm btn-primary" data-toggle="modal"
                        data-target="#newItemModal">
                    Termék hozzáadása
                </button>
            </p>
        <?php endif; ?>
    </div>

    
    <div class="modal fade" id="newItemModal" tabindex="-1" role="dialog" aria-labelledby="newItemModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="form-new-item" action="<?php echo e(action('ItemsController@store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="newItemModalLabel">Új termék</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-row align-items-end">
                            <div class="col">
                                <div class="form-group">
                                    <label for="name">Termék megnevezése</label>
                                    <input type="text" id="name" name="name" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="price">Ár</label>
                                    <div class="input-group mb-3">
                                        <input type="tel" id="price" name="price" class="form-control"
                                               aria-label="Termék ára" aria-describedby="basic-addon2" required>
                                        <div class="input-group-append">
                                            <span class="input-group-text" id="basic-addon2">Ft</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-sm btn-link text-muted" data-dismiss="modal">Bezárás
                        </button>
                        <button type="submit" class="btn btn-sm btn-success">Hozzáadás</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="editItemModal" tabindex="-1" role="dialog" aria-labelledby="editItemModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="form-edit-item" action="<?php echo e(action('ItemsController@update')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden" id="edit_item_id" name="edit_item_id" value="">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editItemModalLabel">Termék szerkesztése</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-row align-items-end">
                            <div class="col">
                                <div class="form-group">
                                    <label for="edit_name">Termék megnevezése</label>
                                    <input type="text" id="edit_name" name="edit_name" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="edit_price">Ár</label>
                                    <div class="input-group mb-3">
                                        <input type="tel" id="edit_price" name="edit_price" class="form-control"
                                               aria-label="Termék ára" aria-describedby="basic-addon2" required>
                                        <div class="input-group-append">
                                            <span class="input-group-text" id="basic-addon2">Ft</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-sm btn-link text-muted" data-dismiss="modal">Bezárás
                        </button>
                        <button type="submit" class="btn btn-sm btn-success">Frissítés</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-scripts'); ?>
    <script>
        $(function () {
            const inputEditItemId = document.getElementById('edit_item_id');
            const inputEditItemName= document.getElementById('edit_name');
            const inputEditItemPrice = document.getElementById('edit_price');

            /**
             * Tárgy szerkesztés
             */
            $('.btn-edit-item').on('click', (e) => {
                inputEditItemId.value = e.currentTarget.dataset.itemId;
                inputEditItemName.value = e.currentTarget.dataset.itemName;
                inputEditItemPrice.value = e.currentTarget.dataset.itemPrice;
            });

            /**
             * Tárgy törlés
             */
            $('.btn-del-item').on('click', (e) => {
                if (!confirm('Biztosan törölni szeretnéd a terméket? Ez a folyamat nem visszafordítható.')) {
                    e.preventDefault();
                }
            });

            $('form').on('submit', (e) => {
                e.stopPropagation();
                const submitBtn = $(e.currentTarget).find('button[type=submit]');
                submitBtn.prop('disabled', true);
                submitBtn.addClass('disabled');
                submitBtn.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>');
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev\www\BioBubi\resources\views/items/index.blade.php ENDPATH**/ ?>