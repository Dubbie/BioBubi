<div id="customer-item-container">
    <div class="form-row align-items-end">
        <div class="col">
            <div class="form-group">
                <label for="item_id_<?php echo e($count); ?>">Termék</label>
                <select name="item_id[]" id="item_id_<?php echo e($count); ?>" class="custom-select customer-item-id">
                    <option value="" disabled selected hidden>Válassz terméket...</option>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" data-price="<?php echo e($item->price); ?>"><?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label for="date_<?php echo e($count); ?>">Időpont</label>
                <input type='text' class="form-control" id="date_<?php echo e($count); ?>" name="date[]">
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label for="price_<?php echo e($count); ?>">Ár</label>
                <div class="input-group mb-0">
                    <input type="tel" id="price_<?php echo e($count); ?>" name="price[]" class="form-control customer-item-price"
                           aria-label="Termék ára" aria-describedby="basic-addon2" required>
                    <div class="input-group-append">
                        <span class="input-group-text" id="basic-addon2">Ft</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label for="quantity_<?php echo e($count); ?>">Mennyiség</label>
                <div class="input-group mb-0">
                    <input type="number" id="quantity_<?php echo e($count); ?>" name="quantity[]" class="form-control customer-item-quantity"
                           aria-label="Termék ára" aria-describedby="basic-addon2" min="1" required>
                    <div class="input-group-append">
                        <span class="input-group-text" id="basic-addon2">db</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-1">
            <div class="form-group">
                <button type="button" class="btn-del-customer-item btn btn-muted">
                    <span class="icon">
                        <i class="far fa-times-circle"></i>
                    </span>
                </button>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\dev\www\BioBubi\resources\views/inc/customer_item.blade.php ENDPATH**/ ?>