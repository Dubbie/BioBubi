<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-start mb-4">
            <h1 class="font-weight-bold">Megrendelők</h1>
            <div class="btn-toolbar">
                <a href="<?php echo e(action('CustomersController@create')); ?>" class="btn btn-sm btn-outline-dark">Új
                    megrendelő</a>
            </div>
        </div>

        
        <?php if(count($customers) > 0): ?>
            <div class="row">
                <div class="col-lg-3">
                    <div class="card card-body border-0 shadow">
                        <form id="form-filter" action="<?php echo e(action('CustomersController@index')); ?>" method="GET">
                            <p class="mb-0">
                                <small class="font-weight-bold">Szűrők</small>
                            </p>

                            <div class="form-group">
                                <label for="filter-name">Név tartalmzza</label>
                                <input type="text" id="filter-name" name="filter-name"
                                       class="form-control form-control-sm" value="<?php echo e($filter['name'] ?? ''); ?>">
                            </div>

                            <p class="mb-0">Város</p>
                            <div class="filter overflow-auto mb-4">
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group mb-0">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input filter-city"
                                                   name="filter-city[]"
                                                   id="filter-city-<?php echo e(\Illuminate\Support\Str::slug($city['city'])); ?>"
                                                   value="<?php echo e($city['city']); ?>"
                                                   <?php if(isset($city['checked'])): ?> checked <?php endif; ?>>
                                            <label class="custom-control-label"
                                                   for="filter-city-<?php echo e(\Illuminate\Support\Str::slug($city['city'])); ?>"><?php echo e($city['city']); ?>

                                                <span class="text-muted"><?php echo e($city['total']); ?></span></label>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div class="form-group mb-0 d-flex justify-content-between">
                                <button type="button" id="btn-reset-filter-form"
                                        class="btn btn-sm btn-link text-secondary px-0">Visszaállít
                                </button>
                                <button type="submit" class="btn btn-sm btn-primary">Szűrés</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-9">
                    <table id="customers-table" class="table table-sm table-hover table-borderless">
                        <thead class="">
                        <tr>
                            <th scope="col" class="tr-clickable" data-sort="string">Név</th>
                            <th scope="col" class="tr-clickable" data-sort="string">Város</th>
                            <th scope="col" class="tr-clickable" data-sort="int">Telefonszám</th>
                            <th scope="col" class="tr-clickable" data-sort="string">E-mail</th>
                            <th scope="col" class="tr-clickable" data-sort="string">Típus</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="tr-clickable action-hover-only"
                                data-redirect-to="<?php echo e(action('CustomersController@show', $customer)); ?>">
                                <td><?php echo e($customer->name); ?></td>
                                <td><?php echo e($customer->address->city); ?></td>
                                <td><?php echo e($customer->phone); ?></td>
                                <td><?php echo e($customer->email); ?></td>
                                <td><?php echo e($customer->getResellerLabel()); ?></td>
                                <td class="td-action text-right">
                                    <a href="<?php echo e(action('CustomersController@edit', $customer)); ?>" class="btn btn-sm btn-muted p-1">
                                        <span class="icon">
                                            <i class="fas fa-pen"></i>
                                        </span>
                                    </a>
                                   <form action="<?php echo e(action('CustomersController@delete', $customer)); ?>" class="d-inline-block" method="POST">
                                       <?php echo csrf_field(); ?>
                                       <?php echo method_field('DELETE'); ?>
                                       <button class="btn btn-del-customer btn-sm btn-muted px-1 py-0">
                                            <span class="icon">
                                                <i class="far fa-times-circle"></i>
                                            </span>
                                       </button>
                                   </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <?php echo e($customers->appends(request()->except('page'))->links()); ?>

                </div>
            </div>
        <?php else: ?>
            <p class="lead mb-2">Nincsen még megrendelő az adatbázisban.</p>
            <p><a href="<?php echo e(action('CustomersController@create')); ?>" class="btn btn-sm btn-primary">Megrendelő
                    hozzáadása</a></p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-scripts'); ?>
    <script>
        $(function () {
            const formFilter = $('#form-filter');

            // Törlő gomb
            $('.btn-del-customer').on('click', (e) => {
                if (!confirm('Biztosan törölni szeretnéd a terméket? Ez a folyamat nem visszafordítható.')) {
                    e.preventDefault();
                }
            });

            // Kattintható sorok
            $('.tr-clickable').on('click', (e) => {
                if (e.currentTarget.dataset.redirectTo &&
                    $(e.target).closest('.btn-del-customer').length === 0
                ) {
                    window.location = e.currentTarget.dataset.redirectTo
                }
            });

            // Reset
            $('#btn-reset-filter-form').on('click', () => {
                // Ürítsük a nevet
                $('#filter-name').val('');

                $('.filter-city').each((i, el) => {
                    el.checked = false;
                });

                formFilter.submit();
            });

            formFilter.submit(function () {
                $(this).find(":input").filter(function () {
                    return !this.value;
                }).attr("disabled", "disabled");
            });
            // Un-disable form fields when page loads, in case they click back after submission or client side validation
            formFilter.find(":input").prop("disabled", false);

            // Stupid table
            $("#customers-table").stupidtable();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev\www\BioBubi\resources\views/customers/index.blade.php ENDPATH**/ ?>