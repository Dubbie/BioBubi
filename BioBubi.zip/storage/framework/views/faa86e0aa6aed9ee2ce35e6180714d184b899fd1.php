<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-start">
            <h1 class="font-weight-bold mb-4">Új termék hozzáadása</h1>
            <div class="btn-toolbar">
                <a href="<?php echo e(action('ItemsController@index')); ?>" class="btn btn-sm btn-link text-decoration-none">Vissza
                    a termékekhez</a>
            </div>
        </div>

        <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <form action="<?php echo e(action('ItemsController@store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-row align-items-end">
                <div class="col">
                    <div class="form-group">
                        <label for="name">Termék megnevezése</label>
                        <input type="text" id="name" name="name" class="form-control" required>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="price">Ár</label>
                        <div class="input-group mb-3">
                            <input type="tel" id="price" name="price" class="form-control"
                                   aria-label="Termék ára" aria-describedby="basic-addon2" required>
                            <div class="input-group-append">
                                <span class="input-group-text" id="basic-addon2">Ft</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-auto">
                    <div class="form-group">
                        <button class="btn btn-success">Hozzáadás</button>
                    </div>
                </div>
            </div>
        </form>
        <p class="lead">Az itt megadott adatokat fogod majd látni, ha rögzíteni szeretnél egy megvásárolt terméket a megrendelő felületen.</p>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-scripts'); ?>
    <script>
        $(function () {
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev\www\BioBubi\resources\views/items/create.blade.php ENDPATH**/ ?>