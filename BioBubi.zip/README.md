## BioBubi

A ultra simple CRM for [semmiszemet.hu](http://semmiszemet.hu/).